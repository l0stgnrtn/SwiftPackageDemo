//
//  Util.h
//  Util
//
//  Created by Nikita Mosiakov on 08.10.2020.
//

#import <Foundation/Foundation.h>

//! Project version number for Util.
FOUNDATION_EXPORT double UtilVersionNumber;

//! Project version string for Util.
FOUNDATION_EXPORT const unsigned char UtilVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Util/PublicHeader.h>


